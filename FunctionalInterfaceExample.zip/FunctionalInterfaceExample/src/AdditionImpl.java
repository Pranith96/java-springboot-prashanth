
public class AdditionImpl implements Addition {

	public void add(int x, int y) {
		int z = x + y;
		System.out.println(z);
	}
}
