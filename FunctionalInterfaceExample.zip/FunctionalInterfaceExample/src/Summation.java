
public interface Summation {
	public int sum(int a, int b);
}
