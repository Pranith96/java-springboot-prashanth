
public class MainMethod {

	public static void main(String[] args) {
		String s = null;
		Example e = new Example();
		e.display(s);
		e.display1(s);
	}
}
